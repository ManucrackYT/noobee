Thank you for choosing for Noobee Theme.

Please follow the steps below for installation:

1. Make sure you have the dependencies for building the Panel assets:
https://pterodactyl.io/community/customization/panel.html

2. Once you have done this, replace the files with those provided in this .ZIP
!! Please note that these are only the files that have been modified in the theme. You must therefore ensure that you only replace these files. Do NOT delete any files!

3. When the files have been successfully installed, run the following commands:
| cd /var/www/pterodactyl
| yarn build:production
| php artisan view:clear

Support is not guaranteed, if you have any problems you can contact us in the following discord server: https://discord.gg/geCjrRbAwC